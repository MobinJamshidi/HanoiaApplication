import 'package:flutter/material.dart';
import 'dart:async';

void main() {
  runApp(HanoiApp());
}

class HanoiApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HanoiPage(),
    );
  }
}

class HanoiPage extends StatefulWidget {
  @override
  _HanoiPageState createState() => _HanoiPageState();
}

class _HanoiPageState extends State<HanoiPage> {
  int numberOfDisks = 3;
  TextEditingController _controller = TextEditingController();
  List<List<int>> towers = [[], [], []];
  List<String> moves = [];
  int currentMove = 0;

  @override
  void initState() {
    super.initState();
    resetTowers();
  }

  void resetTowers() {
    towers = [[], [], []];
    for (int i = numberOfDisks; i > 0; i--) {
      towers[0].add(i);
    }
    moves.clear();
    currentMove = 0;
    setState(() {});
  }

  void solveHanoi(int n, int from, int to, int aux) {
    if (n == 1) {
      moves.add('$from-$to');
      return;
    }
    solveHanoi(n - 1, from, aux, to);
    moves.add('$from-$to');
    solveHanoi(n - 1, aux, to, from);
  }

  void startHanoi() {
    resetTowers();
    solveHanoi(numberOfDisks, 0, 2, 1);
    playMoves();
  }

  void playMoves() async {
    for (String move in moves) {
      List<int> fromTo = move.split('-').map((e) => int.parse(e)).toList();
      int disk = towers[fromTo[0]].removeLast();
      towers[fromTo[1]].add(disk);
      setState(() {});
      await Future.delayed(Duration(seconds: 1));
    }
    // نمایش مرحله پایان و نمایش تمام حرکت‌ها
    showEndDialog();
  }

  void showEndDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("END"),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Movements:"),
                for (String move in moves)
                  Text("Move from tower ${move.split('-')[0]} to tower ${move.split('-')[1]}"),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text("Close"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.purpleAccent, Colors.blueAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: TextField(
                controller: _controller,
                keyboardType: TextInputType.number,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Enter number of disks',
                  labelStyle: TextStyle(color: Colors.white),
                  border: OutlineInputBorder(),
                  filled: true,
                  fillColor: Colors.deepPurple.shade700,
                ),
                onChanged: (value) {
                  numberOfDisks = int.tryParse(value) ?? 3;
                  resetTowers();
                },
              ),
            ),
            SizedBox(height: 40),  // فاصله بیشتر برای TextField
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple.shade700,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 12),
              ),
              onPressed: startHanoi,
              icon: Icon(Icons.play_arrow, size: 30),
              label: Text("Start", style: TextStyle(fontSize: 20)),
            ),
            SizedBox(height: 40),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: List.generate(3, (index) => buildTower(index)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildTower(int towerIndex) {
    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        Container(
          width: 30, // عرض میله را کمی بیشتر کرده‌ایم
          height: 350, // ارتفاع میله بیشتر
          decoration: BoxDecoration(
            color: Colors.brown,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 10)],
          ),
        ),
        ...towers[towerIndex].map((disk) {
          int diskWidth = disk * 30; // اندازه دیسک‌ها
          return Positioned(
            bottom: (towers[towerIndex].indexOf(disk) * 50).toDouble(),
            child: Align(
              alignment: Alignment.center,
              child: Container(
                width: diskWidth.toDouble(),
                height: 50,
                decoration: BoxDecoration(
                  color: getDiskColor(disk),
                  borderRadius: BorderRadius.circular(25),
                  boxShadow: [BoxShadow(color: Colors.black38, blurRadius: 5)],
                ),
                alignment: Alignment.center,
                child: Text(
                  "$disk",
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          );
        }).toList(),
      ],
    );
  }

  Color getDiskColor(int disk) {
    List<Color> colors = [
      Colors.red,
      Colors.blue,
      Colors.green,
      Colors.orange,
      Colors.purple,
      Colors.cyan,
      Colors.amber,
      Colors.pink
    ];
    return colors[disk % colors.length];
  }
}
